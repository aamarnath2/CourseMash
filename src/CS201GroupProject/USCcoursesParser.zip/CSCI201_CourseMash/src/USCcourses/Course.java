
package USCcourses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Course {

    @SerializedName("IsCrossListed")
    @Expose
    private String isCrossListed;
    @SerializedName("PublishedCourseID")
    @Expose
    private String publishedCourseID;
    @SerializedName("ScheduledCourseID")
    @Expose
    private String scheduledCourseID;
    @SerializedName("CourseData")
    @Expose
    private CourseData courseData;

    public String getIsCrossListed() {
        return isCrossListed;
    }

    public void setIsCrossListed(String isCrossListed) {
        this.isCrossListed = isCrossListed;
    }

    public String getPublishedCourseID() {
        return publishedCourseID;
    }

    public void setPublishedCourseID(String publishedCourseID) {
        this.publishedCourseID = publishedCourseID;
    }

    public String getScheduledCourseID() {
        return scheduledCourseID;
    }

    public void setScheduledCourseID(String scheduledCourseID) {
        this.scheduledCourseID = scheduledCourseID;
    }

    public CourseData getCourseData() {
        return courseData;
    }

    public void setCourseData(CourseData courseData) {
        this.courseData = courseData;
    }

}
