
package USCcourses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CSCIcourses {

    @SerializedName("OfferedCourses")
    @Expose
    private OfferedCourses offeredCourses;

    public OfferedCourses getOfferedCourses() {
        return offeredCourses;
    }

    public void setOfferedCourses(OfferedCourses offeredCourses) {
        this.offeredCourses = offeredCourses;
    }

}
