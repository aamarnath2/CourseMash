package USCcourses;

import java.io.FileReader;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.gson.stream.JsonReader;


public class ReadCourses {

	public static void main(String[] args) {
		System.out.println("Please enter a valid file: "); 
		Scanner read = new Scanner(System.in);
		String file = read.nextLine();
		OfferedCourses offeredCourses = null;
		try {
		Gson gson = new Gson();
		JsonReader reader = new JsonReader(new FileReader(file));
		offeredCourses = gson.fromJson(reader, OfferedCourses.class);
		
		}
		catch (java.io.FileNotFoundException e) {
			System.out.println("That file could not be found.");
			//flag1 = true;
		}
		catch (NullPointerException e) {
			System.out.println("That file is an empty JSON file.");
			//flag1 = true;
		}
		catch (JsonParseException e) {
			System.out.println("That file is not a well-formed JSON file.");
			//flag1 = true;
		}	
		System.out.println("Number of Courses: "+ offeredCourses.getCourse().size());
//		 offeredCourses;
		read.close();
	}

}
