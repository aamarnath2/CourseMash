
package USCcourses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CourseData {

    @SerializedName("prefix")
    @Expose
    private String prefix;
    @SerializedName("number")
    @Expose
    private String number;
    @SerializedName("suffix")
    @Expose
    private String suffix;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("units")
    @Expose
    private String units;
    @SerializedName("coreq_text")
    @Expose
    private String coreqText;

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }

    public String getCoreqText() {
        return coreqText;
    }

    public void setCoreqText(String coreqText) {
        this.coreqText = coreqText;
    }

}
